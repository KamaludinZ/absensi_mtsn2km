@extends('layouts.app')

@section('title', 'Dashboard Admin')
@section('page-title', 'Dashboard Admin')

@section('content')
<div class="card mb-8">
    <div class="p-6">
        <div class="flex flex-col md:flex-row justify-between items-start md:items-center mb-6">
            <div>
                <h2 class="text-heading text-gray-800">Dashboard Administrator</h2>
                <p class="text-gray-600 mt-2">Selamat datang di sistem absensi MTsN 2 Kota Malang. Gunakan menu di sisi kiri untuk mengakses fitur-fitur administrasi.</p>
            </div>
            <div class="mt-4 md:mt-0">
                <a href="{{ route('admin.employees.index') }}" class="btn btn-primary mr-2">Kelola Pegawai</a>
                <a href="{{ route('admin.students.index') }}" class="btn btn-secondary">Kelola Siswa</a>
            </div>
        </div>
    </div>
</div>

<div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
    <div class="stat-card bg-gradient-to-br from-blue-50 to-blue-100 border border-blue-100">
        <div class="flex items-center justify-between">
            <div>
                <p class="text-sm font-medium text-blue-600 mb-1">Data Pegawai</p>
                <p class="text-3xl font-bold text-blue-800">{{ $totalEmployees ?? 0 }}</p>
                <p class="text-xs text-blue-600 mt-1">{{ $totalEmployees ?? 0 }} pegawai terdaftar</p>
            </div>
            <div class="bg-blue-100 p-3 rounded-full">
                <svg class="w-8 h-8 text-blue-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M17 20h5v-2a3 3 0 00-5.356-1.857M17 20H7m10 0v-2c0-.656-.126-1.283-.356-1.857M7 20H2v-2a3 3 0 015.356-1.857M7 20v-2c0-.656.126-1.283.356-1.857m0 0a5.002 5.002 0 019.288 0M15 7a3 3 0 11-6 0 3 3 0 016 0zm6 3a2 2 0 11-4 0 2 2 0 014 0zM7 10a2 2 0 11-4 0 2 2 0 014 0z" />
                </svg>
            </div>
        </div>
    </div>

    <div class="stat-card bg-gradient-to-br from-green-50 to-green-100 border border-green-100">
        <div class="flex items-center justify-between">
            <div>
                <p class="text-sm font-medium text-green-600 mb-1">Data Siswa</p>
                <p class="text-3xl font-bold text-green-800">{{ $totalStudents ?? 0 }}</p>
                <p class="text-xs text-green-600 mt-1">{{ $totalStudents ?? 0 }} siswa terdaftar</p>
            </div>
            <div class="bg-green-100 p-3 rounded-full">
                <svg class="w-8 h-8 text-green-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path d="M12 14l9-5-9-5-9 5 9 5z"/>
                    <path d="M12 14l6.16-3.422a12.083 12.083 0 01.665 6.479A11.952 11.952 0 0012 20.055a11.952 11.952 0 00-6.824-2.998 12.078 12.078 0 01.665-6.479L12 14z"/>
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 14l9-5-9-5-9 5 9 5zm0 0l6.16-3.422a12.083 12.083 0 01.665 6.479A11.952 11.952 0 0012 20.055a11.952 11.952 0 00-6.824-2.998 12.078 12.078 0 01.665-6.479L12 14zm-4 6v-7.5l4-2.222" />
                </svg>
            </div>
        </div>
    </div>

    <div class="stat-card bg-gradient-to-br from-purple-50 to-purple-100 border border-purple-100">
        <div class="flex items-center justify-between">
            <div>
                <p class="text-sm font-medium text-purple-600 mb-1">Kehadiran Hari Ini</p>
                <p class="text-3xl font-bold text-purple-800">{{ number_format((($todayEmployeePresent ?? 0 + $todayStudentPresent ?? 0) / max(($totalEmployees ?? 0 + $totalStudents ?? 0), 1)) * 100, 1) }}%</p>
                <p class="text-xs text-purple-600 mt-1">Tingkat Kehadiran</p>
            </div>
            <div class="bg-purple-100 p-3 rounded-full">
                <svg class="w-8 h-8 text-purple-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 5H7a2 2 0 00-2 2v12a2 2 0 002 2h10a2 2 0 002-2V7a2 2 0 00-2-2h-2M9 5a2 2 0 002 2h2a2 2 0 002-2M9 5a2 2 0 012-2h2a2 2 0 012 2m-3 7h3m-3 4h3m-6-4h.01M9 13h.01M9 17h.01M13 13h.01M13 17h.01M17 13h.01M17 17h.01" />
                </svg>
            </div>
        </div>
    </div>

    <div class="stat-card bg-gradient-to-br from-indigo-50 to-indigo-100 border border-indigo-100">
        <div class="flex items-center justify-between">
            <div>
                <p class="text-sm font-medium text-indigo-600 mb-1">Tahun Ajaran</p>
                <p class="text-xl font-bold text-indigo-800">{{ $currentAcademicYear->year_name ?? 'Belum ditentukan' }}</p>
                <p class="text-xs text-indigo-600 mt-1">Tahun Ajaran Aktif</p>
            </div>
            <div class="bg-indigo-100 p-3 rounded-full">
                <svg class="w-8 h-8 text-indigo-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M8 7V3m8 4V3m-9 8h10M5 21h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v12a2 2 0 002 2z" />
                </svg>
            </div>
        </div>
    </div>
</div>

<div class="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-8">
    <div class="card border-card">
        <div class="p-6">
            <div class="flex items-center justify-between mb-4">
                <h3 class="text-subheading font-semibold text-gray-800">Kehadiran Pegawai Hari Ini</h3>
                <a href="{{ route('admin.employees.index') }}" class="text-sm text-blue-600 hover:text-blue-800">Lihat detail →</a>
            </div>
            <div class="flex items-center justify-center h-48">
                <div class="text-center">
                    <p class="text-5xl font-bold text-blue-600">{{ number_format((($todayEmployeePresent ?? 0) / max($totalEmployees ?? 0, 1)) * 100, 1) }}%</p>
                    <p class="text-gray-600 mt-2">Tingkat Kehadiran</p>
                    <p class="text-sm text-gray-500 mt-1">{{ $todayEmployeePresent ?? 0 }}/{{ $totalEmployees ?? 0 }} hadir</p>
                    
                    <!-- Progress bar -->
                    <div class="w-full bg-gray-200 rounded-full h-2.5 mt-4">
                        <div class="bg-blue-600 h-2.5 rounded-full" style="width: {{ number_format((($todayEmployeePresent ?? 0) / max($totalEmployees ?? 0, 1)) * 100, 0) }}%"></div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="card border-card">
        <div class="p-6">
            <div class="flex items-center justify-between mb-4">
                <h3 class="text-subheading font-semibold text-gray-800">Kehadiran Siswa Hari Ini</h3>
                <a href="{{ route('admin.students.index') }}" class="text-sm text-green-600 hover:text-green-800">Lihat detail →</a>
            </div>
            <div class="flex items-center justify-center h-48">
                <div class="text-center">
                    <p class="text-5xl font-bold text-green-600">{{ number_format((($todayStudentPresent ?? 0) / max($totalStudents ?? 0, 1)) * 100, 1) }}%</p>
                    <p class="text-gray-600 mt-2">Tingkat Kehadiran</p>
                    <p class="text-sm text-gray-500 mt-1">{{ $todayStudentPresent ?? 0 }}/{{ $totalStudents ?? 0 }} hadir</p>
                    
                    <!-- Progress bar -->
                    <div class="w-full bg-gray-200 rounded-full h-2.5 mt-4">
                        <div class="bg-green-600 h-2.5 rounded-full" style="width: {{ number_format((($todayStudentPresent ?? 0) / max($totalStudents ?? 0, 1)) * 100, 0) }}%"></div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<div class="grid grid-cols-1 lg:grid-cols-3 gap-6 mb-8">
    <div class="card border-card">
        <div class="p-6">
            <div class="flex items-center mb-4">
                <div class="bg-yellow-100 p-2 rounded-lg mr-3">
                    <svg class="w-6 h-6 text-yellow-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 5H7a2 2 0 00-2 2v12a2 2 0 002 2h10a2 2 0 002-2V7a2 2 0 00-2-2h-2M9 5a2 2 0 002 2h2a2 2 0 002-2M9 5a2 2 0 012-2h2a2 2 0 012 2m-3 7h3m-3 4h3m-6-4h.01M9 13h.01M9 17h.01M13 13h.01M13 17h.01M17 13h.01M17 17h.01" />
                    </svg>
                </div>
                <h3 class="text-subheading font-semibold text-gray-800">Perizinan Pending</h3>
            </div>
            <div class="text-center py-6">
                <p class="text-4xl font-bold text-yellow-600">{{ $pendingPermissions ?? 0 }}</p>
                <p class="text-gray-600 mt-2">Permohonan Tertunda</p>
                <a href="{{ route('admin.permissions.index') }}" class="btn btn-primary mt-4 w-full">Review Izin</a>
            </div>
        </div>
    </div>

    <div class="card border-card">
        <div class="p-6">
            <div class="flex items-center mb-4">
                <div class="bg-pink-100 p-2 rounded-lg mr-3">
                    <svg class="w-6 h-6 text-pink-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 12l2 2 4-4m5.618-4.016A11.955 11.955 0 0112 2.944a11.955 11.955 0 01-8.618 3.04A12.02 12.02 0 003 9c0 5.591 3.824 10.29 9 11.622 5.176-1.332 9-6.03 9-11.622 0-1.042-.133-2.052-.382-3.016z" />
                    </svg>
                </div>
                <h3 class="text-subheading font-semibold text-gray-800">User Monitoring</h3>
            </div>
            <div class="text-center py-6">
                <p class="text-4xl font-bold text-pink-600">{{ $totalMonitoringUsers ?? 0 }}</p>
                <p class="text-gray-600 mt-2">User Monitoring</p>
                <a href="{{ route('admin.users.index') }}" class="btn btn-secondary mt-4 w-full">Lihat Pengguna</a>
            </div>
        </div>
    </div>

    <div class="card border-card">
        <div class="p-6">
            <div class="flex items-center mb-4">
                <div class="bg-teal-100 p-2 rounded-lg mr-3">
                    <svg class="w-6 h-6 text-teal-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 7v10c0 2.21 3.582 4 8 4s8-1.79 8-4V7M4 7c0 2.21 3.582 4 8 4s8-1.79 8-4M4 7c0-2.21 3.582-4 8-4s8 1.79 8 4m0 5c0 2.21-3.582 4-8 4s-8-1.79-8-4" />
                    </svg>
                </div>
                <h3 class="text-subheading font-semibold text-gray-800">Backup Database</h3>
            </div>
            <div class="text-center py-6">
                <p class="text-4xl font-bold text-teal-600">{{ $backupCount ?? 0 }}</p>
                <p class="text-gray-600 mt-2">Backup Tersedia</p>
                <a href="{{ route('admin.backup.index') }}" class="btn btn-secondary mt-4 w-full">Backup Sekarang</a>
            </div>
        </div>
    </div>
</div>

<div class="card border-card mb-8">
    <div class="p-6">
        <h3 class="text-subheading font-semibold text-gray-800 mb-6">Ringkasan Sistem</h3>
        <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
            <div class="bg-gradient-to-br from-blue-50 to-blue-100 rounded-lg p-4 text-center">
                <p class="text-2xl font-bold text-blue-700">{{ $totalGrades ?? 0 }}</p>
                <p class="text-sm text-blue-600 mt-1">Tingkat Kelas</p>
            </div>
            <div class="bg-gradient-to-br from-green-50 to-green-100 rounded-lg p-4 text-center">
                <p class="text-2xl font-bold text-green-700">{{ $totalRombels ?? 0 }}</p>
                <p class="text-sm text-green-600 mt-1">Rombongan Belajar</p>
            </div>
            <div class="bg-gradient-to-br from-purple-50 to-purple-100 rounded-lg p-4 text-center">
                <p class="text-2xl font-bold text-purple-700">{{ $totalSchedules ?? 0 }}</p>
                <p class="text-sm text-purple-600 mt-1">Jadwal Absensi</p>
            </div>
            <div class="bg-gradient-to-br from-indigo-50 to-indigo-100 rounded-lg p-4 text-center">
                <p class="text-2xl font-bold text-indigo-700">{{ $backupCount ?? 0 }}</p>
                <p class="text-sm text-indigo-600 mt-1">Backup Database</p>
            </div>
        </div>
    </div>
</div>

<!-- Holidays This Month Section -->
<div class="card border-card mb-8">
    <div class="p-6">
        <div class="flex items-center justify-between mb-6">
            <div class="flex items-center">
                <div class="bg-amber-100 p-2 rounded-lg mr-3">
                    <svg class="w-6 h-6 text-amber-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M8 7V3m8 4V3m-9 8h10M5 21h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v12a2 2 0 002 2z" />
                    </svg>
                </div>
                <h3 class="text-subheading font-semibold text-gray-800">Hari Libur Bulan {{ \Carbon\Carbon::now()->translatedFormat('F Y') }}</h3>
            </div>
            <a href="{{ route('admin.holidays.index') }}" class="text-blue-600 hover:text-blue-800 text-sm font-medium">
                Kelola Hari Libur →
            </a>
        </div>

        @if($holidaysThisMonth->count() > 0)
            <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                @foreach($holidaysThisMonth as $holiday)
                <div class="bg-gradient-to-br from-amber-50 to-yellow-50 rounded-lg p-4 border border-amber-100">
                    <div class="flex items-start">
                        <div class="bg-amber-100 rounded-lg p-3 mr-3 text-center min-w-[60px]">
                            <p class="text-2xl font-bold text-amber-700">{{ $holiday->date->format('d') }}</p>
                            <p class="text-xs text-amber-600">{{ $holiday->date->translatedFormat('M') }}</p>
                        </div>
                        <div class="flex-1">
                            <h4 class="font-semibold text-gray-800 mb-1">{{ $holiday->name }}</h4>
                            @if($holiday->description)
                                <p class="text-sm text-gray-600">{{ Str::limit($holiday->description, 60) }}</p>
                            @endif
                            <p class="text-xs text-gray-500 mt-2">{{ $holiday->date->translatedFormat('l, d F Y') }}</p>
                        </div>
                    </div>
                </div>
                @endforeach
            </div>
        @else
            <div class="text-center py-8">
                <svg class="w-16 h-16 text-gray-300 mx-auto mb-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M8 7V3m8 4V3m-9 8h10M5 21h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v12a2 2 0 002 2z" />
                </svg>
                <p class="text-gray-500">Tidak ada hari libur pada bulan ini</p>
                <a href="{{ route('admin.holidays.index') }}" class="btn btn-secondary mt-4">Tambah Hari Libur</a>
            </div>
        @endif
    </div>
</div>

{{-- Security Overview --}}
<div class="bg-gradient-to-r from-indigo-600 to-purple-700 rounded-xl shadow-lg overflow-hidden mb-8">
    <div class="p-6">
        <div class="flex flex-col md:flex-row justify-between items-start md:items-center mb-6">
            <div>
                <h3 class="text-xl font-bold flex items-center text-white">
                    <svg class="w-6 h-6 mr-2 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 12l2 2 4-4m5.618-4.016A11.955 11.955 0 0112 2.944a11.955 11.955 0 01-8.618 3.04A12.02 12.02 0 003 9c0 5.591 3.824 10.29 9 11.622 5.176-1.332 9-6.03 9-11.622 0-1.042-.133-2.052-.382-3.016z"/>
                    </svg>
                    Status Keamanan Sistem
                </h3>
                <p class="text-indigo-100 mt-1">Monitor keamanan sistem secara real-time</p>
            </div>
            <a href="{{ route('admin.security.index') }}" class="bg-white text-indigo-600 hover:bg-indigo-50 px-4 py-2 rounded-lg font-semibold transition-colors mt-4 md:mt-0 inline-flex items-center">
                Lihat Detail
                <svg class="w-4 h-4 ml-2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 5l7 7-7 7"/>
                </svg>
            </a>
        </div>

        <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 mb-6">
            <div class="bg-white/20 backdrop-blur-sm rounded-lg p-4 border border-white/30">
                <div class="flex items-center justify-between">
                    <div>
                        <p class="text-sm text-white/90 font-medium">Skor Keamanan</p>
                        <p class="text-3xl font-bold text-white">{{ $securityStats['security_health_score'] ?? 0 }}%</p>
                    </div>
                    <div class="bg-green-500/30 p-2 rounded-full">
                        <svg class="w-8 h-8 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z"/>
                        </svg>
                    </div>
                </div>
            </div>

            <div class="bg-white/20 backdrop-blur-sm rounded-lg p-4 border border-white/30">
                <div class="flex items-center justify-between">
                    <div>
                        <p class="text-sm text-white/90 font-medium">Event Hari Ini</p>
                        <p class="text-3xl font-bold text-white">{{ $securityStats['total_security_events_today'] ?? 0 }}</p>
                    </div>
                    <div class="bg-blue-500/30 p-2 rounded-full">
                        <svg class="w-8 h-8 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z"/>
                        </svg>
                    </div>
                </div>
            </div>

            <div class="bg-white/20 backdrop-blur-sm rounded-lg p-4 border border-white/30">
                <div class="flex items-center justify-between">
                    <div>
                        <p class="text-sm text-white/90 font-medium">Login Gagal</p>
                        <p class="text-3xl font-bold text-white">{{ $securityStats['failed_logins_today'] ?? 0 }}</p>
                    </div>
                    <div class="bg-yellow-500/30 p-2 rounded-full">
                        <svg class="w-8 h-8 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 15v2m-6 4h12a2 2 0 002-2v-6a2 2 0 00-2-2H6a2 2 0 00-2 2v6a2 2 0 002 2zm10-10V7a4 4 0 00-8 0v4h8z"/>
                        </svg>
                    </div>
                </div>
            </div>

            <div class="bg-white/20 backdrop-blur-sm rounded-lg p-4 border border-white/30">
                <div class="flex items-center justify-between">
                    <div>
                        <p class="text-sm text-white/90 font-medium">Event Kritis</p>
                        <p class="text-3xl font-bold text-white">{{ $securityStats['critical_events_today'] ?? 0 }}</p>
                    </div>
                    <div class="bg-red-500/30 p-2 rounded-full">
                        <svg class="w-8 h-8 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-3L13.732 4c-.77-1.333-2.694-1.333-3.464 0L3.34 16c-.77 1.333.192 3 1.732 3z"/>
                        </svg>
                    </div>
                </div>
            </div>
        </div>

        {{-- Security Recommendations --}}
        @if(!empty($securityStats['security_recommendations']))
        <div class="bg-white/20 backdrop-blur-sm rounded-lg p-4 border border-white/30">
            <h4 class="font-semibold mb-4 flex items-center text-white">
                <svg class="w-5 h-5 mr-2 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M13 16h-1v-4h-1m1-4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z"/>
                </svg>
                Rekomendasi Keamanan
            </h4>
            <div class="space-y-3">
                @foreach(array_slice($securityStats['security_recommendations'], 0, 3) as $recommendation)
                <div class="bg-white/10 backdrop-blur-sm rounded-lg px-4 py-3 text-sm flex items-start border border-white/20">
                    <span class="mr-3 mt-0.5 flex-shrink-0">
                        @if($recommendation['type'] === 'critical')
                            <svg class="w-5 h-5 text-red-200" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12" />
                            </svg>
                        @elseif($recommendation['type'] === 'warning')
                            <svg class="w-5 h-5 text-yellow-200" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-3L13.732 4c-.77-1.333-2.694-1.333-3.464 0L3.34 16c-.77 1.333.192 3 1.732 3z" />
                            </svg>
                        @else
                            <svg class="w-5 h-5 text-green-200" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z" />
                            </svg>
                        @endif
                    </span>
                    <div class="flex-1 text-white">
                        <span class="font-semibold">{{ $recommendation['title'] }}:</span> {{ $recommendation['message'] }}
                        @if($recommendation['action'])
                        <a href="{{ $recommendation['action_url'] }}" class="block mt-1 text-blue-200 hover:text-white text-xs underline">
                            {{ $recommendation['action'] }}
                        </a>
                        @endif
                    </div>
                </div>
                @endforeach
            </div>
        </div>
        @endif
    </div>
</div>
@endsection